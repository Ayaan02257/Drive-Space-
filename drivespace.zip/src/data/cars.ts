export interface Car {
  id: string;
  make: string;
  model: string;
  year: number;
  price: number;
  type: 'SUV' | 'Sedan' | 'Sports Car' | 'Hatchback';
  fuelType: 'Electric' | 'Hybrid' | 'Petrol' | 'Diesel';
  transmission: 'Automatic' | 'Manual';
  mileage: number;
  image: string;
  range?: number; // for EV
  '0to60'?: number;
  topSpeed?: number;
  description: string;
}

export const cars: Car[] = [
  {
    id: '1',
    make: 'Tesla',
    model: 'Model S Plaid',
    year: 2024,
    price: 89990,
    type: 'Sedan',
    fuelType: 'Electric',
    transmission: 'Automatic',
    mileage: 150,
    image: 'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=800&q=80',
    range: 359,
    '0to60': 1.99,
    topSpeed: 200,
    description: 'The ultimate electric sedan. Ludicrously fast and incredibly advanced.'
  },
  {
    id: '2',
    make: 'Porsche',
    model: 'Taycan Turbo S',
    year: 2024,
    price: 185000,
    type: 'Sports Car',
    fuelType: 'Electric',
    transmission: 'Automatic',
    mileage: 50,
    image: 'https://images.unsplash.com/photo-1614200187524-dc4b892acf16?auto=format&fit=crop&w=800&q=80',
    range: 222,
    '0to60': 2.6,
    topSpeed: 161,
    description: 'Pure Porsche performance combined with cutting-edge electric architecture.'
  },
  {
    id: '3',
    make: 'Audi',
    model: 'e-tron GT',
    year: 2023,
    price: 104900,
    type: 'Sedan',
    fuelType: 'Electric',
    transmission: 'Automatic',
    mileage: 5000,
    image: 'https://images.unsplash.com/photo-1620891549027-942fdc95d3f5?auto=format&fit=crop&w=800&q=80',
    range: 238,
    '0to60': 3.9,
    topSpeed: 152,
    description: 'A masterpiece of design and electric engineering.'
  },
  {
    id: '4',
    make: 'Rivian',
    model: 'R1S',
    year: 2024,
    price: 84000,
    type: 'SUV',
    fuelType: 'Electric',
    transmission: 'Automatic',
    mileage: 0,
    image: 'https://images.unsplash.com/photo-1694318789531-50db479008bc?auto=format&fit=crop&w=800&q=80',
    range: 352,
    '0to60': 3.0,
    topSpeed: 125,
    description: 'The world\'s most capable fully electric SUV.'
  },
  {
    id: '5',
    make: 'BMW',
    model: 'iX M60',
    year: 2024,
    price: 111500,
    type: 'SUV',
    fuelType: 'Electric',
    transmission: 'Automatic',
    mileage: 120,
    image: 'https://images.unsplash.com/photo-1655209701783-2d50ba90aa31?auto=format&fit=crop&w=800&q=80',
    range: 296,
    '0to60': 3.6,
    topSpeed: 155,
    description: 'A visionary electric SAV built to deliver thrilling M performance.'
  },
  {
    id: '6',
    make: 'Polestar',
    model: '2',
    year: 2023,
    price: 52000,
    type: 'Sedan',
    fuelType: 'Electric',
    transmission: 'Automatic',
    mileage: 15000,
    image: 'https://images.unsplash.com/photo-1633511108257-2ad5e5c7a523?auto=format&fit=crop&w=800&q=80',
    range: 270,
    '0to60': 4.5,
    topSpeed: 127,
    description: 'Avant-garde design meets electric performance in this stunning fastback.'
  },
  {
    id: '7',
    make: 'Mercedes-Benz',
    model: 'EQS 580',
    year: 2023,
    price: 125950,
    type: 'Sedan',
    fuelType: 'Electric',
    transmission: 'Automatic',
    mileage: 200,
    image: 'https://images.unsplash.com/photo-1699946452899-73fb76fd4909?auto=format&fit=crop&w=800&q=80',
    range: 340,
    '0to60': 4.1,
    topSpeed: 130,
    description: 'The S-Class of electric vehicles. Unmatched luxury and aerodynamics.'
  },
  {
    id: '8',
    make: 'Lexus',
    model: 'RX 450h',
    year: 2022,
    price: 48000,
    type: 'SUV',
    fuelType: 'Hybrid',
    transmission: 'Automatic',
    mileage: 32000,
    image: 'https://images.unsplash.com/photo-1692257256673-d14214f08c35?auto=format&fit=crop&w=800&q=80',
    '0to60': 7.9,
    topSpeed: 124,
    description: 'A smooth and refined hybrid SUV with exceptional reliability.'
  }
];
