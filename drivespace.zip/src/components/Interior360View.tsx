import { useState, useRef, useEffect } from 'react';
import { View, ChevronLeft, ChevronRight } from 'lucide-react';

const INTERIOR_IMAGES = [
  'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1503376713745-f0ea9fb713ed?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1551833726-b6530dd0122f?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1601051515275-c54641c88880?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1582046894567-eb901844bdf9?auto=format&fit=crop&w=1200&q=80'
];

export function Interior360View() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  // Preload images
  useEffect(() => {
    INTERIOR_IMAGES.forEach(src => {
      const img = new Image();
      img.src = src;
    });
  }, []);

  const handleDragStart = (clientX: number) => {
    setIsDragging(true);
    setStartX(clientX);
  };

  const handleDragMove = (clientX: number) => {
    if (!isDragging) return;
    
    const deltaX = clientX - startX;
    const sensitivity = 30; // pixels to move before changing frame

    if (Math.abs(deltaX) > sensitivity) {
      const direction = deltaX > 0 ? -1 : 1;
      let nextIndex = currentIndex + direction;
      
      if (nextIndex >= INTERIOR_IMAGES.length) nextIndex = 0;
      if (nextIndex < 0) nextIndex = INTERIOR_IMAGES.length - 1;
      
      setCurrentIndex(nextIndex);
      setStartX(clientX);
    }
  };

  const handleDragEnd = () => {
    setIsDragging(false);
  };

  const nextFrame = () => {
    setCurrentIndex((prev) => (prev + 1) % INTERIOR_IMAGES.length);
  };

  const prevFrame = () => {
    setCurrentIndex((prev) => (prev - 1 + INTERIOR_IMAGES.length) % INTERIOR_IMAGES.length);
  };

  return (
    <div className="flex flex-col space-y-4">
      <div 
        className="relative w-full aspect-[16/9] md:aspect-[21/9] rounded-2xl overflow-hidden glass border-0 cursor-grab active:cursor-grabbing group"
        ref={containerRef}
        onMouseDown={(e) => handleDragStart(e.clientX)}
        onMouseMove={(e) => handleDragMove(e.clientX)}
        onMouseUp={handleDragEnd}
        onMouseLeave={handleDragEnd}
        onTouchStart={(e) => handleDragStart(e.touches[0].clientX)}
        onTouchMove={(e) => handleDragMove(e.touches[0].clientX)}
        onTouchEnd={handleDragEnd}
      >
        {INTERIOR_IMAGES.map((src, idx) => (
          <img
            key={src}
            src={src}
            alt={`Interior View ${idx + 1}`}
            className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 pointer-events-none select-none ${
              idx === currentIndex ? 'opacity-100 z-10' : 'opacity-0 z-0'
            }`}
             draggable={false}
          />
        ))}

        {/* Overlay Hint */}
        <div className="absolute inset-x-0 bottom-4 z-20 flex justify-center pointer-events-none opacity-100 group-hover:opacity-0 transition-opacity duration-500">
           <div className="glass px-4 py-2 rounded-full flex items-center gap-2 text-white">
             <View className="w-4 h-4 text-sky-400" />
             <span className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Drag to look around</span>
           </div>
        </div>

        {/* Manual Controls (Mobile / Click focus) */}
        <button 
          onClick={(e) => { e.stopPropagation(); prevFrame(); }}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full glass flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-white/10"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <button 
          onClick={(e) => { e.stopPropagation(); nextFrame(); }}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full glass flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-white/10"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      <div className="flex justify-center gap-2">
        {INTERIOR_IMAGES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentIndex(idx)}
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              idx === currentIndex ? 'bg-sky-400 w-6' : 'bg-slate-700 hover:bg-slate-500'
            }`}
            aria-label={`Go to frame ${idx + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
