import { X, Check } from 'lucide-react';
import { useState } from 'react';
import { Car } from '../data/cars';

interface TestDriveModalProps {
  isOpen: boolean;
  onClose: () => void;
  car: Car;
}

export function TestDriveModal({ isOpen, onClose, car }: TestDriveModalProps) {
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 3000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#0F172A]/80 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative glass w-full max-w-lg rounded-3xl p-8 border border-white/10 shadow-2xl overflow-y-auto max-h-[90vh]">
        <button onClick={onClose} className="absolute top-6 right-6 p-2 text-slate-400 hover:text-white transition-colors bg-slate-900/50 hover:bg-slate-800 rounded-xl">
          <X className="w-5 h-5" />
        </button>
        
        {submitted ? (
          <div className="py-12 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 bg-sky-500/20 text-sky-400 rounded-full flex items-center justify-center mb-6 border border-sky-400/30">
              <Check className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Request Received</h3>
            <p className="text-slate-400 text-sm">We'll be in touch shortly to confirm your appointment for the {car.make} {car.model}.</p>
          </div>
        ) : (
          <>
            <h2 className="text-2xl font-black uppercase tracking-tight text-white mb-2">Book Test Drive</h2>
            <p className="text-slate-400 text-sm mb-6">Experience the {car.make} {car.model} firsthand.</p>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-2">First Name</label>
                  <input type="text" required className="w-full bg-slate-900/50 border border-white/10 rounded focus:border-sky-500 focus:outline-none px-4 py-3 text-white text-sm" />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-2">Last Name</label>
                  <input type="text" required className="w-full bg-slate-900/50 border border-white/10 rounded focus:border-sky-500 focus:outline-none px-4 py-3 text-white text-sm" />
                </div>
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-2">Email Address</label>
                <input type="email" required className="w-full bg-slate-900/50 border border-white/10 rounded focus:border-sky-500 focus:outline-none px-4 py-3 text-white text-sm" />
              </div>
              <div>
                <label className="block text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-2">Phone Number</label>
                <input type="tel" required className="w-full bg-slate-900/50 border border-white/10 rounded focus:border-sky-500 focus:outline-none px-4 py-3 text-white text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-2">Preferred Date</label>
                  <input type="date" required className="w-full bg-slate-900/50 border border-white/10 rounded focus:border-sky-500 focus:outline-none px-4 py-3 text-white text-sm [color-scheme:dark]" />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-2">Preferred Time</label>
                  <select required className="w-full bg-slate-900/50 border border-white/10 rounded focus:border-sky-500 focus:outline-none px-4 py-3 text-white text-sm">
                    <option value="">Select a time</option>
                    <option value="morning">Morning (9AM - 12PM)</option>
                    <option value="afternoon">Afternoon (12PM - 4PM)</option>
                    <option value="evening">Evening (4PM - 7PM)</option>
                  </select>
                </div>
              </div>
              <div className="pt-4">
                <button type="submit" className="w-full py-4 bg-sky-500 hover:bg-sky-400 text-slate-900 font-bold uppercase tracking-widest text-[10px] rounded shadow-lg shadow-sky-500/20 transition-all">
                  Confirm Request
                </button>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
