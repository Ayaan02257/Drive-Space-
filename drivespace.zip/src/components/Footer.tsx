export function Footer() {
  return (
    <footer className="bg-[#0A0F1D] border-t border-slate-800/50 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-1">
            <span className="text-xl font-black tracking-tighter uppercase text-white">DriveSpace<span className="text-sky-400">.</span></span>
            <p className="mt-4 text-xs uppercase tracking-widest text-slate-500 max-w-xs">
              Your premium destination for modern electric, hybrid, and luxury vehicles.
            </p>
          </div>
          <div>
            <h3 className="text-xs font-bold text-white tracking-widest uppercase mb-4">Inventory</h3>
            <ul className="space-y-2 text-xs uppercase tracking-widest text-slate-500">
              <li><a href="/inventory?type=SUV" className="hover:text-white transition-colors">SUVs</a></li>
              <li><a href="/inventory?type=Sedan" className="hover:text-white transition-colors">Sedans</a></li>
              <li><a href="/inventory?type=Sports Car" className="hover:text-white transition-colors">Sports Cars</a></li>
              <li><a href="/inventory?fuelType=Electric" className="hover:text-white transition-colors">Electric Vehicles</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-xs font-bold text-white tracking-widest uppercase mb-4">Services</h3>
            <ul className="space-y-2 text-xs uppercase tracking-widest text-slate-500">
              <li><a href="/finance" className="hover:text-white transition-colors">Finance Calculator</a></li>
              <li><a href="/finance" className="hover:text-white transition-colors">Apply for Finance</a></li>
              <li><a href="/contact" className="hover:text-white transition-colors">Book a Test Drive</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-xs font-bold text-white tracking-widest uppercase mb-4">Support</h3>
            <ul className="space-y-2 text-xs uppercase tracking-widest text-slate-500">
              <li><a href="/contact" className="hover:text-white transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors">FAQs</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-slate-800/50 flex flex-col md:flex-row justify-between items-center text-xs uppercase tracking-widest">
          <p className="text-slate-500">
            &copy; {new Date().getFullYear()} DriveSpace. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
