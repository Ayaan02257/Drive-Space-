import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Car, LayoutDashboard, Calculator, Phone } from 'lucide-react';
import { useComparison } from '../context/ComparisonContext';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const { comparedCars } = useComparison();

  const links = [
    { name: 'Home', path: '/', icon: LayoutDashboard },
    { name: 'Inventory', path: '/inventory', icon: Car },
    { name: 'Finance', path: '/finance', icon: Calculator },
    { name: 'Contact', path: '/contact', icon: Phone },
  ];

  const compareLink = { name: `Compare (${comparedCars.length})`, path: '/compare' };

  return (
    <nav className="glass border-b border-white/10 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0">
              <span className="text-xl font-black tracking-tighter uppercase text-white">DriveSpace<span className="text-sky-400">.</span></span>
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {links.map((link) => {
                const isActive = location.pathname === link.path;
                return (
                  <Link
                    key={link.name}
                    to={link.path}
                    className={`${
                      isActive
                        ? 'text-sky-400 border-b-2 border-sky-400'
                        : 'text-slate-400 hover:text-white transition-colors duration-200'
                    } px-1 py-2 text-xs font-bold uppercase tracking-widest`}
                  >
                    {link.name}
                  </Link>
                );
              })}
              {comparedCars.length > 0 && (
                <Link
                  to={compareLink.path}
                  className={`text-sky-400 font-bold px-1 py-2 text-xs uppercase tracking-widest border-b-2 ${location.pathname === compareLink.path ? 'border-sky-400' : 'border-transparent'}`}
                >
                  {compareLink.name}
                </Link>
              )}
            </div>
          </div>
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-slate-400 hover:text-white hover:bg-slate-800/50 focus:outline-none"
            >
              <span className="sr-only">Open main menu</span>
              {isOpen ? <X className="block h-6 w-6" aria-hidden="true" /> : <Menu className="block h-6 w-6" aria-hidden="true" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 glass border-t border-white/10">
            {links.map((link) => {
              const isActive = location.pathname === link.path;
              const Icon = link.icon;
              return (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`${
                    isActive ? 'bg-slate-800/50 text-sky-400' : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
                  } flex items-center px-3 py-2 rounded-md text-xs font-bold uppercase tracking-widest`}
                >
                  <Icon className="w-5 h-5 mr-3" />
                  {link.name}
                </Link>
              );
            })}
             {comparedCars.length > 0 && (
                <Link
                  to={compareLink.path}
                   onClick={() => setIsOpen(false)}
                  className="text-sky-400 flex items-center px-3 py-2 rounded-md text-xs font-bold uppercase tracking-widest hover:bg-slate-800/50"
                >
                  {compareLink.name}
                </Link>
              )}
          </div>
        </div>
      )}
    </nav>
  );
}
