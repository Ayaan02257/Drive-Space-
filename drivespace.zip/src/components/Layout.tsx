import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { Outlet } from 'react-router-dom';
import { AIChatWidget } from './AIChatWidget';

export function Layout() {
  return (
    <div className="min-h-screen bg-[#0F172A] text-slate-100 font-sans flex flex-col">
      <Navbar />
      <main className="flex-grow flex flex-col">
        <Outlet />
      </main>
      <Footer />
      <AIChatWidget />
    </div>
  );
}
