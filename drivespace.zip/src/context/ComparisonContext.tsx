import { createContext, useContext, useState, ReactNode } from 'react';
import { Car } from '../data/cars';

interface ComparisonContextType {
  comparedCars: Car[];
  addCarToCompare: (car: Car) => void;
  removeCarFromCompare: (carId: string) => void;
  clearComparison: () => void;
}

const ComparisonContext = createContext<ComparisonContextType | undefined>(undefined);

export function ComparisonProvider({ children }: { children: ReactNode }) {
  const [comparedCars, setComparedCars] = useState<Car[]>([]);

  const addCarToCompare = (car: Car) => {
    if (comparedCars.length < 3 && !comparedCars.find((c) => c.id === car.id)) {
      setComparedCars([...comparedCars, car]);
    }
  };

  const removeCarFromCompare = (carId: string) => {
    setComparedCars(comparedCars.filter((c) => c.id !== carId));
  };

  const clearComparison = () => {
    setComparedCars([]);
  };

  return (
    <ComparisonContext.Provider value={{ comparedCars, addCarToCompare, removeCarFromCompare, clearComparison }}>
      {children}
    </ComparisonContext.Provider>
  );
}

export function useComparison() {
  const context = useContext(ComparisonContext);
  if (context === undefined) {
    throw new Error('useComparison must be used within a ComparisonProvider');
  }
  return context;
}
