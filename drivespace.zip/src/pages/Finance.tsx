import { useState } from 'react';

export function Finance() {
  const [age, setAge] = useState<number | ''>('');
  const [eligibilityResult, setEligibilityResult] = useState<'pending' | 'eligible' | 'ineligible'>('pending');

  const checkEligibility = (e: React.FormEvent) => {
    e.preventDefault();
    if (age === '') return;
    
    // Assignment logic implementation
    if (Number(age) >= 18) {
      setEligibilityResult('eligible');
    } else {
      setEligibilityResult('ineligible');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full flex-grow">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-black tracking-tight uppercase text-white mb-4 text-center">Finance Your Dream Car</h1>
        <p className="text-slate-400 mb-12 text-center text-lg">
          Flexible financing options designed around your lifestyle. Check your eligibility below.
        </p>

        <div className="glass rounded-3xl p-6 md:p-10 mb-12 border-0">
          <h2 className="text-2xl font-bold text-white mb-6 border-b border-white/10 pb-4">Eligibility Checker</h2>
          
          <form onSubmit={checkEligibility} className="mb-8">
            <div className="flex flex-col sm:flex-row gap-4 items-end">
              <div className="w-full">
                <label htmlFor="age" className="block text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">Please enter your age</label>
                <input
                  type="number"
                  id="age"
                  value={age}
                  onChange={(e) => setAge(e.target.value === '' ? '' : Number(e.target.value))}
                  required
                  min="0"
                  className="w-full bg-slate-900/50 border border-white/10 rounded text-white px-4 py-3 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                  placeholder="e.g. 25"
                />
              </div>
              <button 
                type="submit"
                className="w-full sm:w-auto px-8 py-3 bg-sky-500 hover:bg-sky-400 text-slate-900 font-bold uppercase tracking-widest text-[10px] rounded shadow-lg shadow-sky-500/20 transition-colors"
              >
                Check Eligibility
              </button>
            </div>
          </form>

          {eligibilityResult === 'eligible' && (
            <div className="bg-sky-500/10 border border-sky-500/20 text-sky-400 p-6 rounded-2xl">
              <h3 className="text-xl font-bold mb-2">You are eligible to apply for car finance!</h3>
              <p className="mb-6 opacity-90 text-sm">Please proceed to the full application form below.</p>
              
              <form className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs uppercase tracking-widest text-sky-400/80 mb-2">First Name</label>
                    <input type="text" className="w-full bg-slate-900/50 border border-sky-400/20 rounded text-white px-4 py-2" required />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-widest text-sky-400/80 mb-2">Last Name</label>
                    <input type="text" className="w-full bg-slate-900/50 border border-sky-400/20 rounded text-white px-4 py-2" required />
                  </div>
                </div>
                <div>
                   <label className="block text-xs uppercase tracking-widest text-sky-400/80 mb-2">Annual Income ($)</label>
                   <input type="number" className="w-full bg-slate-900/50 border border-sky-400/20 rounded text-white px-4 py-2" required />
                </div>
                <button type="button" className="w-full py-3 bg-white hover:bg-slate-200 text-slate-900 font-bold uppercase tracking-widest text-[10px] rounded transition-colors mt-4">
                  Submit Finance Application
                </button>
              </form>
            </div>
          )}

          {eligibilityResult === 'ineligible' && (
            <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-6 rounded-2xl">
              <h3 className="text-xl font-bold mb-2">You are not eligible for car finance</h3>
              <p className="opacity-90 text-sm">Applicants must be 18 years of age or older to apply for financing. Please contact our showroom if you have questions.</p>
            </div>
          )}
        </div>

        {/* Finance Calculator */}
        <div className="glass rounded-3xl p-6 md:p-10 border-0">
          <h2 className="text-2xl font-bold text-white mb-6 border-b border-white/10 pb-4">Estimate Payments</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <label className="flex justify-between text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">
                  <span>Vehicle Price</span>
                  <span className="text-sky-400">$50,000</span>
                </label>
                <input type="range" min="10000" max="200000" defaultValue="50000" className="w-full accent-sky-500" />
              </div>
              <div>
                <label className="flex justify-between text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">
                  <span>Down Payment</span>
                  <span className="text-sky-400">$10,000</span>
                </label>
                <input type="range" min="0" max="50000" defaultValue="10000" className="w-full accent-sky-500" />
              </div>
              <div>
                <label className="flex justify-between text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">
                  <span>Term (Months)</span>
                  <span className="text-sky-400">60</span>
                </label>
                <input type="range" min="24" max="84" step="12" defaultValue="60" className="w-full accent-sky-500" />
              </div>
            </div>
            <div className="bg-slate-900/50 p-6 rounded-2xl border border-white/10 flex flex-col justify-center text-center">
              <span className="text-slate-400 text-[10px] uppercase tracking-widest font-bold mb-2">Estimated Monthly Payment</span>
              <span className="text-5xl font-mono text-sky-400 mb-2 glow-text">$743</span>
              <span className="text-[10px] text-slate-500 uppercase tracking-widest">Based on 4.9% APR (Estimated)</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
