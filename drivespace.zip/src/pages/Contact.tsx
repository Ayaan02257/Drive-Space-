import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export function Contact() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full flex-grow">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-black tracking-tight uppercase text-white mb-4">Contact Us</h1>
        <p className="text-lg text-slate-400 max-w-2xl mx-auto">
          Our team of automotive experts is here to assist you with inquiries, test drives, and service appointments.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Contact Info */}
        <div className="space-y-8">
          <div className="glass p-8 rounded-3xl border-0">
            <h2 className="text-2xl font-bold text-white mb-8 border-b border-white/10 pb-4">Showroom Details</h2>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="flex-shrink-0 h-12 w-12 bg-sky-500/10 rounded-2xl flex items-center justify-center border border-sky-400/20 text-sky-400">
                  <MapPin className="h-5 w-5" />
                </div>
                <div className="ml-4">
                  <h3 className="text-base font-bold uppercase tracking-wider text-white">Location</h3>
                  <p className="mt-1 text-sm text-slate-400">100 Luxury Avenue<br />Motor District, CA 90210</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0 h-12 w-12 bg-sky-500/10 rounded-2xl flex items-center justify-center border border-sky-400/20 text-sky-400">
                  <Phone className="h-5 w-5" />
                </div>
                <div className="ml-4">
                  <h3 className="text-base font-bold uppercase tracking-wider text-white">Phone</h3>
                  <p className="mt-1 text-sm text-slate-400">Sales: (555) 012-3456<br />Service: (555) 012-3457</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0 h-12 w-12 bg-sky-500/10 rounded-2xl flex items-center justify-center border border-sky-400/20 text-sky-400">
                  <Mail className="h-5 w-5" />
                </div>
                <div className="ml-4">
                  <h3 className="text-base font-bold uppercase tracking-wider text-white">Email</h3>
                  <p className="mt-1 text-sm text-slate-400">sales@drivespace.com<br />support@drivespace.com</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0 h-12 w-12 bg-sky-500/10 rounded-2xl flex items-center justify-center border border-sky-400/20 text-sky-400">
                  <Clock className="h-5 w-5" />
                </div>
                <div className="ml-4">
                  <h3 className="text-base font-bold uppercase tracking-wider text-white">Hours</h3>
                  <p className="mt-1 text-sm text-slate-400">Mon - Fri: 9:00 AM - 7:00 PM<br />Sat: 10:00 AM - 5:00 PM<br />Sun: Closed</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="glass p-8 rounded-3xl border-0">
           <h2 className="text-2xl font-bold text-white mb-8 border-b border-white/10 pb-4">Send an Enquiry</h2>
           <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); alert("Enquiry Sent!");}}>
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="first-name" className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">First name</label>
                  <input type="text" id="first-name" className="w-full bg-slate-900/50 border border-white/10 rounded text-white px-4 py-3 focus:outline-none focus:border-sky-500" required />
                </div>
                <div>
                  <label htmlFor="last-name" className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Last name</label>
                  <input type="text" id="last-name" className="w-full bg-slate-900/50 border border-white/10 rounded text-white px-4 py-3 focus:outline-none focus:border-sky-500" required />
                </div>
             </div>
             
             <div>
                <label htmlFor="email" className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Email address</label>
                <input type="email" id="email" className="w-full bg-slate-900/50 border border-white/10 rounded text-white px-4 py-3 focus:outline-none focus:border-sky-500" required />
              </div>

              <div>
                <label htmlFor="subject" className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Subject</label>
                <select id="subject" className="w-full bg-slate-900/50 border border-white/10 rounded text-white px-4 py-3 focus:outline-none focus:border-sky-500" required>
                  <option>Book a Test Drive</option>
                  <option>Finance Enquiry</option>
                  <option>Vehicle Information</option>
                  <option>Other</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2">Message</label>
                <textarea id="message" rows={4} className="w-full bg-slate-900/50 border border-white/10 rounded text-white px-4 py-3 focus:outline-none focus:border-sky-500" required></textarea>
              </div>

              <button type="submit" className="w-full py-4 bg-sky-500 hover:bg-sky-400 text-slate-900 font-bold uppercase tracking-widest text-[10px] rounded shadow-lg shadow-sky-500/20 transition-colors">
                Submit Enquiry
              </button>
           </form>
        </div>
      </div>
    </div>
  );
}
