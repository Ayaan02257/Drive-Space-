import { useParams, Link } from 'react-router-dom';
import { cars } from '../data/cars';
import { useComparison } from '../context/ComparisonContext';
import { Check, ArrowLeft, Fuel, Gauge, Activity, Calendar } from 'lucide-react';
import { useState } from 'react';
import { TestDriveModal } from '../components/TestDriveModal';
import { Interior360View } from '../components/Interior360View';

export function CarDetails() {
  const { id } = useParams();
  const car = cars.find(c => c.id === id);
  const { addCarToCompare, comparedCars, removeCarFromCompare } = useComparison();
  const [activeTab, setActiveTab] = useState<'interior' | 'specs' | 'finance' | 'configure'>('interior');
  const [activeColor, setActiveColor] = useState<string>('transparent');
  const [isModalOpen, setIsModalOpen] = useState(false);

  if (!car) {
    return (
      <div className="flex-grow flex items-center justify-center p-8 text-center text-white">
        <div>
          <h2 className="text-2xl font-bold mb-4">Vehicle Not Found</h2>
          <Link to="/inventory" className="text-red-500 hover:underline">Return to Inventory</Link>
        </div>
      </div>
    );
  }

  const isCompared = comparedCars.some(c => c.id === car.id);

  return (
    <div className="bg-[#0F172A] min-h-screen pb-16">
      {/* Hero Image */}
      <div className="w-full h-[50vh] md:h-[70vh] relative overflow-hidden">
         <img
            src={car.image}
            alt={`${car.make} ${car.model}`}
            className="w-full h-full object-cover relative z-0 grayscale"
          />
          {/* Color Tint Overlay */}
          <div 
            className="absolute inset-0 z-10 transition-colors duration-500 mix-blend-color" 
            style={{ backgroundColor: activeColor !== 'transparent' ? activeColor : 'transparent' }} 
          />
          {/* Dark Gradient Overlay */}
          <div className="absolute inset-0 hero-gradient z-20 pointer-events-none opacity-80"></div>
          <div className="absolute top-8 left-4 md:left-8 z-30">
            <Link to="/inventory" className="inline-flex items-center text-white glass px-4 py-2 rounded font-bold uppercase tracking-widest text-[10px] hover:bg-white/10 transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Inventory
            </Link>
          </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-32 relative z-30">
        <div className="glass rounded-3xl p-6 md:p-10 shadow-2xl">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-8 border-b border-slate-700/50 pb-8">
            <div>
              <p className="text-sky-400 font-bold tracking-[0.2em] uppercase mb-2 text-sm">{car.make}</p>
              <h1 className="text-4xl md:text-5xl font-black text-white mb-2 tracking-tight">{car.model}</h1>
              <p className="text-slate-400 text-sm uppercase tracking-widest">{car.year} • {car.type}</p>
            </div>
            <div className="text-left md:text-right">
              <p className="text-3xl md:text-4xl font-mono text-sky-400 mb-4 glow-text">${car.price.toLocaleString()}</p>
              <div className="flex gap-3">
                 <button
                    onClick={() => isCompared ? removeCarFromCompare(car.id) : addCarToCompare(car)}
                    disabled={!isCompared && comparedCars.length >= 3}
                    className={`px-6 py-3 text-[10px] font-bold uppercase tracking-widest text-center rounded transition-all shadow-xl ${
                      isCompared 
                        ? 'bg-sky-500/20 border border-sky-400/50 text-sky-400' 
                        : comparedCars.length >= 3 
                          ? 'opacity-50 cursor-not-allowed border border-slate-800 text-slate-500' 
                          : 'bg-white text-slate-900 border border-transparent'
                    }`}
                  >
                    {isCompared ? <span className="flex items-center justify-center"><Check className="w-4 h-4 mr-2"/> In Comparison</span> : 'Compare Vehicle'}
                  </button>
                  <button
                    onClick={() => setIsModalOpen(true)}
                    className="px-6 py-3 bg-sky-500 hover:bg-sky-400 text-slate-900 font-bold rounded uppercase tracking-widest text-[10px] shadow-xl shadow-sky-500/20 transition-colors"
                  >
                    Book Test Drive
                  </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <p className="text-slate-300 text-lg leading-relaxed mb-10">
                {car.description}
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mb-12 border-y border-slate-700/50 py-8">
                <div className="flex flex-col">
                  <span className="text-slate-500 uppercase tracking-widest text-[10px] mb-1 flex items-center"><Fuel className="w-4 h-4 mr-1 text-sky-400" /> Fuel</span>
                  <span className="text-white font-bold">{car.fuelType}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-slate-500 uppercase tracking-widest text-[10px] mb-1 flex items-center"><Gauge className="w-4 h-4 mr-1 text-sky-400" /> Mileage</span>
                  <span className="text-white font-bold">{car.mileage.toLocaleString()} mi</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-slate-500 uppercase tracking-widest text-[10px] mb-1 flex items-center"><Activity className="w-4 h-4 mr-1 text-sky-400" /> Transmission</span>
                  <span className="text-white font-bold">{car.transmission}</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-slate-500 uppercase tracking-widest text-[10px] mb-1 flex items-center"><Calendar className="w-4 h-4 mr-1 text-sky-400" /> Year</span>
                  <span className="text-white font-bold">{car.year}</span>
                </div>
              </div>

              <div className="mb-8">
                <div className="flex border-b border-white/10 mb-6 overflow-x-auto hide-scrollbar">
                  <button 
                    onClick={() => setActiveTab('interior')}
                    className={`pb-4 px-4 font-bold uppercase tracking-widest text-[10px] transition-colors border-b-2 whitespace-nowrap ${activeTab === 'interior' ? 'border-sky-400 text-sky-400' : 'border-transparent text-slate-500 hover:text-white'}`}
                  >
                    Interior 360
                  </button>
                  <button 
                    onClick={() => setActiveTab('specs')}
                    className={`pb-4 px-4 font-bold uppercase tracking-widest text-[10px] transition-colors border-b-2 whitespace-nowrap ${activeTab === 'specs' ? 'border-sky-400 text-sky-400' : 'border-transparent text-slate-500 hover:text-white'}`}
                  >
                    Performance Specs
                  </button>
                  <button 
                     onClick={() => setActiveTab('finance')}
                    className={`pb-4 px-4 font-bold uppercase tracking-widest text-[10px] transition-colors border-b-2 whitespace-nowrap ${activeTab === 'finance' ? 'border-sky-400 text-sky-400' : 'border-transparent text-slate-500 hover:text-white'}`}
                  >
                    Est. Financing
                  </button>
                  <button 
                     onClick={() => setActiveTab('configure')}
                    className={`pb-4 px-4 font-bold uppercase tracking-widest text-[10px] transition-colors border-b-2 whitespace-nowrap ${activeTab === 'configure' ? 'border-sky-400 text-sky-400' : 'border-transparent text-slate-500 hover:text-white'}`}
                  >
                    Configure
                  </button>
                </div>

                {activeTab === 'interior' && (
                  <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <Interior360View />
                  </div>
                )}

                {activeTab === 'specs' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
                    {car.range && (
                      <div className="flex justify-between py-3 border-b border-slate-800/50">
                        <span className="text-slate-400 font-medium">Range</span>
                        <span className="text-sky-400 font-mono">{car.range} miles</span>
                      </div>
                    )}
                    {car['0to60'] && (
                      <div className="flex justify-between py-3 border-b border-slate-800/50">
                        <span className="text-slate-400 font-medium">0 - 60 mph</span>
                        <span className="text-sky-400 font-mono">{car['0to60']} s</span>
                      </div>
                    )}
                     {car.topSpeed && (
                      <div className="flex justify-between py-3 border-b border-slate-800/50">
                        <span className="text-slate-400 font-medium">Top Speed</span>
                        <span className="text-sky-400 font-mono">{car.topSpeed} mph</span>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'finance' && (
                  <div className="p-6 glass rounded-xl">
                    <h3 className="text-white font-bold mb-4">Estimated Monthly Payment</h3>
                    <div className="flex items-end gap-2 mb-6">
                      <span className="text-4xl font-mono glow-text text-sky-400">${Math.round(car.price * 0.018)}</span>
                      <span className="text-slate-400 mb-1 uppercase tracking-widest text-[10px]">/ mo</span>
                    </div>
                    <ul className="space-y-2 text-sm text-slate-400 mb-6 font-medium">
                      <li className="flex justify-between"><span>Term</span><span className="text-white">60 months</span></li>
                      <li className="flex justify-between"><span>APR</span><span className="text-white">4.9%</span></li>
                      <li className="flex justify-between"><span>Down Payment</span><span className="text-white">20% (${Math.round(car.price * 0.2).toLocaleString()})</span></li>
                    </ul>
                    <Link to="/finance" className="block w-full py-3 bg-white text-slate-900 text-center font-bold tracking-widest uppercase text-[10px] rounded hover:bg-slate-200 transition-colors">
                      Customize Financing
                    </Link>
                  </div>
                )}

                {activeTab === 'configure' && (
                  <div className="p-6 glass rounded-xl">
                    <h3 className="text-white font-bold mb-6">Select Exterior Finish</h3>
                    <div className="flex flex-wrap gap-4">
                      {[
                        { name: 'Factory Default', color: 'transparent', class: 'bg-gradient-to-tr from-gray-300 to-gray-500' },
                        { name: 'Obsidian Black', color: '#111111', class: 'bg-[#111111]' },
                        { name: 'Alpine White', color: '#f8f8f8', class: 'bg-[#f8f8f8]' },
                        { name: 'Crimson Red', color: '#991b1b', class: 'bg-[#991b1b]' },
                        { name: 'Midnight Blue', color: '#1e3a8a', class: 'bg-[#1e3a8a]' },
                        { name: 'Racing Green', color: '#14532d', class: 'bg-[#14532d]' }
                      ].map((opt) => (
                        <button
                          key={opt.name}
                          onClick={() => setActiveColor(opt.color)}
                          className={`w-14 h-14 rounded-full border-4 transition-all ${
                            activeColor === opt.color ? 'border-sky-400 scale-110' : 'border-white/10 hover:border-white/30'
                          } ${opt.class}`}
                          title={opt.name}
                          aria-label={`Select ${opt.name}`}
                        />
                      ))}
                    </div>
                    <p className="mt-6 text-xs text-slate-400 uppercase tracking-widest">
                      Our configurator provides an approximation of exterior finish options. Exact availability varies by model.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar / CTA */}
            <div>
              <div className="glass p-6 rounded-2xl">
                <h3 className="text-xl font-bold text-white mb-4">Interested?</h3>
                <p className="text-sm text-slate-400 mb-6">Contact our sales team to discuss this {car.make} or arrange a viewing in our showroom.</p>
                <Link to={`/contact?subject=Enquiry: ${car.make} ${car.model}`} className="block w-full py-3 bg-sky-500 hover:bg-sky-400 text-slate-900 text-center font-bold uppercase tracking-widest text-[10px] rounded shadow-xl shadow-sky-500/20 transition-colors mb-4">
                  Contact Sales
                </Link>
                <a href="tel:5550123" className="block w-full py-3 border border-white/20 hover:border-white/50 text-white text-center font-bold uppercase tracking-widest text-[10px] rounded transition-colors">
                   (555) 012-3456
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <TestDriveModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} car={car} />
    </div>
  );
}
