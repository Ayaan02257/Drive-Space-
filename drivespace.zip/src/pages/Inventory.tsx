import { useState, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { cars } from '../data/cars';
import { useComparison } from '../context/ComparisonContext';
import { Filter, Check, X } from 'lucide-react';

export function Inventory() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { addCarToCompare, comparedCars, removeCarFromCompare } = useComparison();
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  const filterType = searchParams.get('type');
  const filterFuel = searchParams.get('fuelType');
  const sort = searchParams.get('sort') || 'price-asc';

  const updateFilter = (key: string, value: string | null) => {
    const newParams = new URLSearchParams(searchParams);
    if (value) {
      newParams.set(key, value);
    } else {
      newParams.delete(key);
    }
    setSearchParams(newParams);
  };

  const filteredCars = useMemo(() => {
    let result = cars;
    if (filterType) result = result.filter((c) => c.type === filterType);
    if (filterFuel) result = result.filter((c) => c.fuelType === filterFuel);

    result = [...result].sort((a, b) => {
      if (sort === 'price-asc') return a.price - b.price;
      if (sort === 'price-desc') return b.price - a.price;
      if (sort === 'year-desc') return b.year - a.year;
      return 0;
    });

    return result;
  }, [filterType, filterFuel, sort]);

  const FilterSidebar = () => (
    <div className="space-y-8">
      <div>
        <h3 className="text-lg font-semibold text-white mb-4">Body Type</h3>
        <div className="space-y-2">
          {['SUV', 'Sedan', 'Sports Car'].map((type) => (
            <label key={type} className="flex items-center">
              <input
                type="checkbox"
                checked={filterType === type}
                onChange={() => updateFilter('type', filterType === type ? null : type)}
                className="rounded border-neutral-700 bg-neutral-900 text-red-500 shadow-sm focus:border-red-500 focus:ring focus:ring-red-500 focus:ring-opacity-50"
              />
              <span className="ml-2 text-sm text-neutral-300">{type}</span>
            </label>
          ))}
        </div>
      </div>
      <div>
        <h3 className="text-lg font-semibold text-white mb-4">Fuel Type</h3>
        <div className="space-y-2">
          {['Electric', 'Hybrid', 'Petrol'].map((fuel) => (
            <label key={fuel} className="flex items-center">
              <input
                type="checkbox"
                checked={filterFuel === fuel}
                onChange={() => updateFilter('fuelType', filterFuel === fuel ? null : fuel)}
                className="rounded border-neutral-700 bg-neutral-900 text-red-500 shadow-sm focus:border-red-500 focus:ring focus:ring-red-500 focus:ring-opacity-50"
              />
              <span className="ml-2 text-sm text-neutral-300">{fuel}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
      <h1 className="text-4xl font-black tracking-tight uppercase text-white mb-8">Browse Inventory</h1>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Mobile Filter Toggle */}
        <div className="md:hidden">
          <button
            onClick={() => setIsMobileFilterOpen(!isMobileFilterOpen)}
            className="flex items-center justify-between w-full px-4 py-3 glass text-white rounded-xl border border-white/10 font-bold uppercase tracking-widest text-xs"
          >
            <span className="flex items-center"><Filter className="w-5 h-5 mr-2" /> Filters</span>
            {isMobileFilterOpen ? <X className="w-5 h-5" /> : null}
          </button>
          
          {isMobileFilterOpen && (
            <div className="mt-4 p-4 glass rounded-xl border border-white/10">
               <FilterSidebar />
            </div>
          )}
        </div>

        {/* Desktop Sidebar Filter */}
        <aside className="hidden md:block w-64 flex-shrink-0">
          <FilterSidebar />
        </aside>

        {/* Main Content */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-6 pb-4 border-b border-slate-800/50">
            <span className="text-slate-400 text-sm tracking-widest uppercase">{filteredCars.length} Results</span>
            <div className="flex items-center">
              <label htmlFor="sort" className="mr-3 text-xs tracking-widest uppercase text-slate-400">Sort by:</label>
              <select
                id="sort"
                value={sort}
                onChange={(e) => updateFilter('sort', e.target.value)}
                className="bg-slate-900/50 border border-slate-800 text-white text-sm rounded focus:ring-sky-500 focus:border-sky-500 block p-2"
              >
                <option value="price-asc">Price (Low to High)</option>
                <option value="price-desc">Price (High to Low)</option>
                <option value="year-desc">Newest First</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredCars.map((car) => {
               const isCompared = comparedCars.some(c => c.id === car.id);
               return (
              <div key={car.id} className="glass rounded-2xl car-card overflow-hidden flex flex-col group">
                <Link to={`/car/${car.id}`} className="block relative aspect-[4/3] overflow-hidden rounded-t-2xl">
                  <img
                    src={car.image}
                    alt={`${car.make} ${car.model}`}
                    className="w-full h-full object-cover transform transition-all duration-700 group-hover:scale-105 grayscale group-hover:grayscale-0"
                  />
                  <div className="absolute top-2 left-2 flex gap-2">
                     <span className="px-2 py-1 text-[10px] font-bold uppercase tracking-[0.2em] bg-slate-900/80 text-white backdrop-blur-sm rounded">
                      {car.year}
                    </span>
                  </div>
                </Link>
                <div className="p-5 flex-grow flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <Link to={`/car/${car.id}`}>
                      <h3 className="text-lg font-bold text-white group-hover:text-sky-400 transition-colors">
                        {car.make} {car.model}
                      </h3>
                    </Link>
                  </div>
                  <p className="text-sm font-mono text-sky-400 mb-4">${car.price.toLocaleString()}</p>
                  
                  <div className="grid grid-cols-2 gap-y-2 text-[10px] text-slate-400 uppercase tracking-widest mb-6">
                    <div>{car.type}</div>
                    <div>{car.fuelType}</div>
                    <div>{car.mileage.toLocaleString()} mi</div>
                    <div>{car.transmission}</div>
                  </div>

                  <div className="mt-auto grid grid-cols-2 gap-3">
                    <Link
                      to={`/car/${car.id}`}
                      className="px-4 py-2 bg-slate-800/50 hover:bg-slate-700 text-white text-[10px] uppercase tracking-widest font-bold text-center rounded transition-colors"
                    >
                      View Details
                    </Link>
                    <button
                      onClick={() => isCompared ? removeCarFromCompare(car.id) : addCarToCompare(car)}
                      disabled={!isCompared && comparedCars.length >= 3}
                      className={`px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-center rounded transition-colors border ${
                        isCompared 
                          ? 'bg-sky-500/20 border-sky-400/50 text-sky-400' 
                          : comparedCars.length >= 3 
                            ? 'opacity-50 cursor-not-allowed border-slate-800 text-slate-500' 
                            : 'border-white/10 hover:border-sky-400 text-white'
                      }`}
                    >
                      {isCompared ? <span className="flex items-center justify-center"><Check className="w-4 h-4 mr-1"/> Added</span> : 'Compare'}
                    </button>
                  </div>
                </div>
              </div>
            )})}
          </div>
        </div>
      </div>
    </div>
  );
}
