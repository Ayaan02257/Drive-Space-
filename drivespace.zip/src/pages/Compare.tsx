import { useState } from 'react';
import { useComparison } from '../context/ComparisonContext';
import { Link } from 'react-router-dom';
import { X, AlertCircle } from 'lucide-react';

export function Compare() {
  const { comparedCars, removeCarFromCompare, clearComparison } = useComparison();

  if (comparedCars.length === 0) {
    return (
      <div className="flex-grow flex items-center justify-center py-20 px-4">
        <div className="text-center max-w-md">
           <div className="w-16 h-16 bg-neutral-900 rounded-full flex items-center justify-center mx-auto mb-6 text-neutral-500">
            <AlertCircle className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Compare Vehicles</h2>
          <p className="text-neutral-400 mb-8">You haven't added any vehicles to compare yet. Browse our inventory and select up to 3 cars to compare their features side-by-side.</p>
          <Link to="/inventory" className="px-8 py-3 bg-sky-500 hover:bg-sky-400 text-slate-900 font-bold uppercase tracking-widest text-[10px] rounded shadow-lg shadow-sky-500/20 transition-colors inline-block">
            Browse Inventory
          </Link>
        </div>
      </div>
    );
  }

  const features = [
    { label: 'Price', get: (c: any) => `$${c.price.toLocaleString()}` },
    { label: 'Type', get: (c: any) => c.type },
    { label: 'Year', get: (c: any) => c.year },
    { label: 'Fuel Type', get: (c: any) => c.fuelType },
    { label: 'Transmission', get: (c: any) => c.transmission },
    { label: 'Mileage', get: (c: any) => `${c.mileage.toLocaleString()} mi` },
    { label: '0-60 mph', get: (c: any) => c['0to60'] ? `${c['0to60']} s` : 'N/A' },
    { label: 'Top Speed', get: (c: any) => c.topSpeed ? `${c.topSpeed} mph` : 'N/A' },
    { label: 'EV Range', get: (c: any) => c.range ? `${c.range} miles` : 'N/A' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full flex-grow">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-4xl font-black tracking-tight text-white uppercase mb-2">Compare Vehicles</h1>
          <p className="text-slate-400">Comparing {comparedCars.length} of 3 maximum vehicles</p>
        </div>
        <button 
          onClick={clearComparison}
          className="text-[10px] uppercase tracking-widest font-bold text-slate-500 hover:text-white transition-colors underline"
        >
          Clear All
        </button>
      </div>

      <div className="overflow-x-auto pb-8">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr>
              <th className="w-48 p-4 border-b border-white/10 bg-[#0F172A] z-10 sticky left-0"></th>
              {comparedCars.map((car) => (
                <th key={`header-${car.id}`} className="min-w-[280px] w-1/3 p-4 border-b border-white/10 align-top">
                  <div className="relative group rounded-2xl overflow-hidden mb-4 glass border-0 car-card">
                    <button 
                      onClick={() => removeCarFromCompare(car.id)}
                      className="absolute top-2 right-2 z-10 bg-slate-900/60 hover:bg-rose-500 text-white p-1.5 rounded-xl backdrop-blur-sm transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <div className="aspect-[4/3] w-full">
                      <img src={car.image} alt={car.model} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">{car.make} {car.model}</h3>
                  <Link to={`/car/${car.id}`} className="text-sky-400 hover:text-sky-300 text-[10px] uppercase tracking-widest font-bold inline-block">
                    View Details
                  </Link>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {features.map((feature, idx) => (
              <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                <td className="w-48 p-4 border-b border-white/5 font-bold uppercase text-[10px] tracking-widest text-slate-500 sticky left-0 bg-[#0F172A]">
                  {feature.label}
                </td>
                {comparedCars.map((car) => (
                  <td key={`${car.id}-${idx}`} className="p-4 border-b border-white/5 text-white font-medium">
                    {feature.get(car)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {comparedCars.length < 3 && (
        <div className="mt-8 text-center">
           <Link to="/inventory" className="px-8 py-3 border border-white/20 hover:border-white/50 text-white uppercase tracking-widest text-[10px] font-bold rounded transition-colors inline-block">
            Add Another Vehicle
          </Link>
        </div>
      )}
    </div>
  );
}
