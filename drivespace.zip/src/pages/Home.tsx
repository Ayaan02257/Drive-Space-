import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Shield, Star, Crown } from 'lucide-react';
import { cars } from '../data/cars';

export function Home() {
  const featuredCars = cars.slice(0, 3);

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=2000&q=80"
            alt="Luxury modern car"
            className="w-full h-full object-cover opacity-60 mix-blend-overlay"
          />
          <div className="absolute inset-0 hero-gradient"></div>
        </div>
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-black tracking-tight uppercase text-white mb-6">
            Find Your <span className="text-sky-400 glow-text">Perfect</span> Car Today
          </h1>
          <p className="text-lg md:text-xl text-slate-300 font-normal mb-10 max-w-2xl mx-auto">
            Discover a curated collection of modern, electric, and luxury vehicles designed to elevate your drive.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/inventory"
              className="px-8 py-4 bg-sky-500 hover:bg-sky-400 text-slate-900 font-bold rounded-full shadow-lg shadow-sky-500/20 uppercase tracking-widest text-xs transition-all duration-300 flex items-center w-full sm:w-auto justify-center"
            >
              Browse Cars <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
            <Link
              to="/finance"
              className="px-8 py-4 bg-transparent border border-white/20 hover:border-white/50 text-white font-bold rounded-full uppercase tracking-widest text-xs transition-all duration-300 w-full sm:w-auto text-center"
            >
              Finance Options
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Vehicles */}
      <section className="py-24 bg-[#0F172A] border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl font-black tracking-tight uppercase text-white mb-2">Featured Vehicles</h2>
              <p className="text-slate-400">Handpicked selections from our premium inventory.</p>
            </div>
            <Link to="/inventory" className="hidden sm:flex items-center text-xs tracking-widest uppercase font-bold text-sky-400 hover:text-sky-300">
              View All <ArrowRight className="ml-1 w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredCars.map((car) => (
              <Link key={car.id} to={`/car/${car.id}`} className="group glass rounded-2xl car-card flex flex-col">
                <div className="aspect-[16/9] overflow-hidden relative rounded-t-2xl">
                  <img
                    src={car.image}
                    alt={`${car.make} ${car.model}`}
                    className="w-full h-full object-cover transform transition-all duration-700 group-hover:scale-105 grayscale group-hover:grayscale-0"
                  />
                  <div className="absolute top-4 left-4 flex gap-2">
                    <span className="px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] bg-slate-900/80 text-white backdrop-blur-sm rounded">
                      {car.year}
                    </span>
                    {car.fuelType === 'Electric' && (
                      <span className="px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] bg-sky-500/20 text-sky-400 border border-sky-500/30 rounded">
                        EV
                      </span>
                    )}
                  </div>
                </div>
                <div className="p-6 flex-grow flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-white group-hover:text-sky-400 transition-colors">
                        {car.make} {car.model}
                      </h3>
                      <p className="text-slate-400 text-xs mt-1 uppercase tracking-wider">{car.type}</p>
                    </div>
                    <span className="text-sm font-mono text-sky-400">${car.price.toLocaleString()}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-auto pt-4 border-t border-slate-700/50">
                    <div className="flex flex-col">
                      <span className="text-[10px] text-slate-500 uppercase tracking-widest">0-60 mph</span>
                      <span className="text-xs text-slate-300 font-medium">{car['0to60']}s</span>
                    </div>
                    {car.range && (
                      <div className="flex flex-col">
                        <span className="text-[10px] text-slate-500 uppercase tracking-widest">Range</span>
                        <span className="text-xs text-slate-300 font-medium">{car.range} mi</span>
                      </div>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
          <div className="mt-8 text-center sm:hidden">
            <Link to="/inventory" className="inline-flex items-center justify-center px-6 py-3 border border-slate-700 text-xs font-bold tracking-widest uppercase rounded-full text-white hover:bg-slate-800 w-full transition-colors">
              View All Vehicles
            </Link>
          </div>
        </div>
      </section>

      {/* Browse by Category */}
      <section className="py-24 bg-[#0A0F1D] border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-black tracking-tight uppercase text-white mb-12 text-center">Browse by Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Link to="/inventory?type=SUV" className="relative group overflow-hidden rounded-2xl aspect-video glass border-0 car-card">
              <img src="https://images.unsplash.com/photo-1694318789531-50db479008bc?auto=format&fit=crop&w=800&q=80" alt="SUVs" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 grayscale group-hover:grayscale-0 transition-transform duration-700 opacity-60 group-hover:opacity-80" />
              <div className="absolute inset-0 flex items-center justify-center">
                <h3 className="text-2xl font-black text-white tracking-widest uppercase glow-text">SUVs</h3>
              </div>
            </Link>
            <Link to="/inventory?type=Sedan" className="relative group overflow-hidden rounded-2xl aspect-video glass border-0 car-card">
              <img src="https://images.unsplash.com/photo-1620891549027-942fdc95d3f5?auto=format&fit=crop&w=800&q=80" alt="Sedans" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 grayscale group-hover:grayscale-0 transition-transform duration-700 opacity-60 group-hover:opacity-80" />
              <div className="absolute inset-0 flex items-center justify-center">
                <h3 className="text-2xl font-black text-white tracking-widest uppercase glow-text">Sedans</h3>
              </div>
            </Link>
            <Link to="/inventory?type=Sports Car" className="relative group overflow-hidden rounded-2xl aspect-video glass border-0 car-card">
              <img src="https://images.unsplash.com/photo-1614200187524-dc4b892acf16?auto=format&fit=crop&w=800&q=80" alt="Sports Cars" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 grayscale group-hover:grayscale-0 transition-transform duration-700 opacity-60 group-hover:opacity-80" />
              <div className="absolute inset-0 flex items-center justify-center">
                <h3 className="text-2xl font-black text-white tracking-widest uppercase glow-text">Sports Cars</h3>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-[#0F172A] border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-black tracking-tight uppercase text-white mb-4">Why Choose Us</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">Experience a new standard in automotive retail.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center border-t border-slate-800/50 pt-16">
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 glass rounded-2xl flex items-center justify-center mb-6 text-sky-400">
                <Crown className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3 tracking-wide">Premium Selection</h3>
              <p className="text-slate-400 text-sm leading-relaxed">Curated inventory of high-end vehicles, rigorously inspected for the highest quality.</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 glass rounded-2xl flex items-center justify-center mb-6 text-sky-400">
                <Zap className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3 tracking-wide">EV Specialists</h3>
              <p className="text-slate-400 text-sm leading-relaxed">Experts in electric vehicles, ready to guide your transition to sustainable driving.</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 glass rounded-2xl flex items-center justify-center mb-6 text-sky-400">
                <Shield className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3 tracking-wide">Transparent Finance</h3>
              <p className="text-slate-400 text-sm leading-relaxed">Clear pricing, customizable finance options, and no hidden fees.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
