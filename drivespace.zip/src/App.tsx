/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Inventory } from './pages/Inventory';
import { CarDetails } from './pages/CarDetails';
import { Finance } from './pages/Finance';
import { Contact } from './pages/Contact';
import { Compare } from './pages/Compare';
import { ComparisonProvider } from './context/ComparisonContext';

export default function App() {
  return (
    <Router>
      <ComparisonProvider>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="inventory" element={<Inventory />} />
            <Route path="car/:id" element={<CarDetails />} />
            <Route path="finance" element={<Finance />} />
            <Route path="contact" element={<Contact />} />
            <Route path="compare" element={<Compare />} />
          </Route>
        </Routes>
      </ComparisonProvider>
    </Router>
  );
}
