import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import cors from "cors";

// Initialize Gemini
const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // API Route for chat widget
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, chatHistory } = req.body;
      
      const systemInstruction = `You are an expert car sales assistant for DriveSpace. 
      Help users find their perfect car based on their budget, preferences, and lifestyle.
      You have access to our inventory data (you can assume we sell modern EV and Luxury vehicles from top brands like Tesla, Porsche, Rivian, Lucid, BMW, Audi, Mercedes).
      Keep your answers concise, helpful, and friendly. Guide them towards scheduling a test drive or viewing inventory.`;

      const chat = ai.chats.create({
        model: "gemini-3.5-flash",
        config: {
          systemInstruction,
        },
      });

      // Simple implementation: just pass the user message. 
      // For full chat history, we'd reconstruct the history array, but here we'll just send the latest message for simplicity, 
      // or we can map the history if we want to be more accurate. Wait, the SDK's chat.sendMessage maintains its own history if we keep the instance, 
      // but in stateless HTTP we should ideally pass history. Since we don't have a simple way to init chat with history in the new SDK easily with just create(), 
      // we'll just pass the context in the message or use generateContent. Let's use generateContent with history.

      const contents = chatHistory.map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
      }));
      contents.push({ role: 'user', parts: [{ text: message }] });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents,
        config: {
          systemInstruction,
          temperature: 0.7
        }
      });

      res.json({ text: response.text });
    } catch (error) {
      console.error('Error generating chat response:', error);
      res.status(500).json({ error: 'Failed to generate response' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
